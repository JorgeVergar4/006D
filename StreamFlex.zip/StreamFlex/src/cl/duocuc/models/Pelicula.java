/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duocuc.models;

/**
 *
 * @author Cetecom
 */
public class Pelicula extends Filmografia {
    private double calificacion;
    private double duracion;

    public Pelicula() {
    }

    public Pelicula(double calificacion, double duracion) {
        this.calificacion = calificacion;
        this.duracion = duracion;
    }

    public Pelicula(double calificacion, double duracion, String idFilm, String titulo) {
        super(idFilm, titulo);
        this.calificacion = calificacion;
        this.duracion = duracion;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return "Pelicula{" + "calificacion=" + calificacion + ", duracion=" + duracion + '}';
    }

    
    @Override
    public double costoBase() {
        if(calificacion >4.5){
            return COSTO_BASE_SUSCRIPCION*1.10;
        }else{
            return COSTO_BASE_SUSCRIPCION;
        }
    }
    
    
}
