/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cl.duocuc.models;

/**
 *
 * @author Cetecom
 */
public interface IReglas {
    double COSTO_BASE_SUSCRIPCION = 12000;
    
    double costoBase();
    
    
}
