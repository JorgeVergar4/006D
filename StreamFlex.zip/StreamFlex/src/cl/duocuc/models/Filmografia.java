/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duocuc.models;

/**
 *
 * @author Cetecom
 */
public abstract class Filmografia implements IReglas{
    private String idFilm, titulo;


    public Filmografia() {
    }

    public Filmografia(String idFilm, String titulo) {
        this.idFilm = idFilm;
        this.titulo = titulo;
    }

    public String getIdFilm() {
        return idFilm;
    }

    public void setIdFilm(String idFilm) {
        this.idFilm = idFilm;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "Filmografia{" + "idFilm=" + idFilm + ", titulo=" + titulo + '}';
    }

    

    
    


    
    
 
    
    
    
    
    
    
}
