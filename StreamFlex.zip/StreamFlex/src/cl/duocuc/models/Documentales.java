/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duocuc.models;

/**
 *
 * @author Cetecom
 */
public class Documentales extends Filmografia{
    private double duracion;
    

    public Documentales() {
    }

    public Documentales(double duracion) {
        this.duracion = duracion;
    }

    public Documentales(double duracion, String idFilm, String titulo) {
        super(idFilm, titulo);
        this.duracion = duracion;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }
    

 
    @Override
    public double costoBase() {
        if(duracion>90){
            return COSTO_BASE_SUSCRIPCION*0.95;
        }else{
            return COSTO_BASE_SUSCRIPCION;
        }
        
    }
    


    


    
    
    
    
}
