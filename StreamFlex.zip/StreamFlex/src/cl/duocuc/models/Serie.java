/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duocuc.models;

/**
 *
 * @author Cetecom
 */
public class Serie extends Filmografia{
    private double temporadas;
    private boolean estadoSerie;

    public Serie() {
    }

    public Serie(double temporadas, boolean estadoSerie) {
        this.temporadas = temporadas;
        this.estadoSerie = estadoSerie;
    }

    public Serie(double temporadas, boolean estadoSerie, String idFilm, String titulo) {
        super(idFilm, titulo);
        this.temporadas = temporadas;
        this.estadoSerie = estadoSerie;
    }

    public double getTemporadas() {
        return temporadas;
    }

    public void setTemporadas(double temporadas) {
        this.temporadas = temporadas;
    }

    public boolean isEstadoSerie() {
        return estadoSerie;
    }

    public void setEstadoSerie(boolean estadoSerie) {
        this.estadoSerie = estadoSerie;
    }

    @Override
    public String toString() {
        return "Serie{" + "temporadas=" + temporadas + ", estadoSerie=" + estadoSerie + '}';
    }
    
    
    @Override
    public double costoBase() {
        if(temporadas > 3 && estadoSerie ==false){
            return COSTO_BASE_SUSCRIPCION*1.08;
        }else{
            return COSTO_BASE_SUSCRIPCION;
        }
    }
    

    
    
    
    
    
    
    
    
}
