/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package streamflex;

import cl.duocuc.models.Documentales;
import cl.duocuc.models.Filmografia;
import cl.duocuc.models.Pelicula;
import cl.duocuc.models.Serie;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Cetecom
 */
public class StreamFlex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pelicula peliculas= new Pelicula();
        Serie series = new Serie();

        Scanner entrada = new Scanner(System.in);
        List<Filmografia> listadoFilm = new ArrayList<>();
        
        
        int opcion = 0;
        while(opcion!=5){
            System.out.println("---StreamFlex---");
            System.out.println("1)Ingresar Pelicula");
            System.out.println("2)Ingresar Serie");
            System.out.println("3)Ingresar Documental");
            System.out.println("4)Contenido Disponible");
            System.out.println("5)Salir");
            
            opcion= entrada.nextInt();
            entrada.nextLine();
            
            switch(opcion){
                case 1:
                    System.out.println("Ingrese un id para tu pelicula (P001)");
                    String idPelicula = entrada.next();
        
                    System.out.println("Ingrese un titulo para su pelicula");
                    String tituloPelicula = entrada.next();
        
                    System.out.println("Duracion pelicula");
        
                    double duracionPelicula = entrada.nextDouble();
        
                    System.out.println("Calificacion pelicula (1/10)");
                    double calificacion = entrada.nextDouble();
        
                    Filmografia pelicula = new Pelicula(calificacion, duracionPelicula, idPelicula, tituloPelicula);
                    listadoFilm.add(pelicula);
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Pelicula){
                            System.out.println("Titulo pelicula: " +i.getTitulo()+
                                    "Calificacion: "+((Pelicula) i).getCalificacion()
                            +"Costo pelicula "+ i.costoBase());
                        }else{
                       }
                        break;
                    
                case 2:
                    System.out.println("Ingrese un id para tu Serie (S001)");
                    String idSerie = entrada.next();
        
                    System.out.println("Ingrese un titulo para su Serie");
                    String tituloSerie = entrada.next();
        
        
                    System.out.println("Temporadas de la serie");        
                    double temporadas = entrada.nextDouble();
   
                    System.out.println("Estado serie (True/False)");
                    boolean estadoSerie = entrada.nextBoolean();
                    
                    Filmografia serie = new Serie(temporadas, estadoSerie, idSerie, tituloSerie);
                    listadoFilm.add(serie);
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Serie){
                            System.out.println("Titulo Serie: " +i.getTitulo()+
                                    "Temporadas: "+ ((Serie) i).getTemporadas());
                            System.out.println("Costo: "+ i.costoBase());
                        }else{
                       }
                    
                    break;
                case 3:
                    System.out.println("Ingrese un id para el documental (D001)");
                    String idDocumental = entrada.next();
                    
                    System.out.println("Ingrese un titulo para el documental");
                    String tituloDocumental = entrada.next();
                    
                    System.out.println("Ingrese la duracion de su documental");
                    double duracionDocumental = entrada.nextDouble();
                    
                    Filmografia documental = new Documentales(duracionDocumental, idDocumental, tituloDocumental);
                    
                    listadoFilm.add(documental);
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Documentales){
                            System.out.println("Titulo documental: " +i.getTitulo()+
                                    "Duracion: "+((Documentales) i).getDuracion());
                            System.out.println("Costo: "+ i.costoBase());
                        }else{
                       }
                   
                    break;
                case 4: 
                    System.out.println("Contenido disponible Peliculas");
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Pelicula){
                            System.out.println("Titulo pelicula: " +i.getTitulo()+
                                    "Calificacion: "+((Pelicula) i).getCalificacion()
                            +"Costo pelicula "+ i.costoBase());
                        }else{

                       }
                    
                    System.out.println("Contenido disponible Series");
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Serie){
                            System.out.println("Titulo Serie: " +i.getTitulo()+
                                    "Temporadas: "+ ((Serie) i).getTemporadas());
                            System.out.println("Costo: "+ i.costoBase());
                        }else{

                       }
                    System.out.println("Contenido disponible documentales");
                    for (Filmografia i: listadoFilm)
                        if(i instanceof Documentales){
                            System.out.println("Titulo documental: " +i.getTitulo()+
                                    "Duracion: "+((Documentales) i).getDuracion());
                            System.out.println("Costo: "+ i.costoBase());
                        }else{
 
                       }
                    
                    System.out.println("Cantidad de contenido en total disponible"+listadoFilm.size());
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;

                    
            }
            
        }
        
    }


    
}
